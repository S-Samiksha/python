# Tic-Tac-Toe
print("Tic-Tac-Toe")

# Create the board
positions = ["TL", "TC", "TR",
             "ML", "MC", "MR",
             "BL", "BC", "BR"]
board = {}
for position in positions:
    board[position] = " "

# Set player symbols
currentPlayer, nextPlayer = "X", "O"

# Print the board
print()
print(" ", board["TL"], "|", board["TC"], "|", board["TR"], " ")
print("----+---+----")
print(" ", board["ML"], "|", board["MC"], "|", board["MR"])
print("----+---+----")
print(" ", board["BL"], "|", board["BC"], "|", board["BR"], " ")
print()

# Main gameplay loop
while True:
    # Get the move of current Player and update Board
    while True:
        print("Enter move for", currentPlayer)
        position = input()
        if (position in board.keys()) and (board[position] == " "):
            board[position] = currentPlayer
            break
        else:
            print("Sorry, wrong move. Check again.")

    # Print the updated Board
    print()
    print(" ", board["TL"], "|", board["TC"], "|", board["TR"], " ")
    print("----+---+----")
    print(" ", board["ML"], "|", board["MC"], "|", board["MR"])
    print("----+---+----")
    print(" ", board["BL"], "|", board["BC"], "|", board["BR"], " ")
    print()
        
    # Check for terminate-or-continue conditions
    isWinner = ((board['TL'] == board['TC'] == board['TR'] == currentPlayer) or # Top Row
                (board['ML'] == board['MC'] == board['MR'] == currentPlayer) or # Middle Row
                (board['BL'] == board['BC'] == board['BR'] == currentPlayer) or # Bottom Row
                (board['TL'] == board['ML'] == board['BL'] == currentPlayer) or # Left Column
                (board['TC'] == board['MC'] == board['BC'] == currentPlayer) or # Center Column
                (board['TR'] == board['MR'] == board['BR'] == currentPlayer) or # Right Column
                (board['TL'] == board['MC'] == board['BR'] == currentPlayer) or # Diagonal
                (board['TR'] == board['MC'] == board['BL'] == currentPlayer))   # Diagonal
    if isWinner:
        # If the current Player Won the game
        print("Congratulations!", currentPlayer, "has won the game.")
        break
    elif not any(position == " " for position in board.values()):
        # If the Board is full and it's a Tie
        print("Wow! This game is a tie. Play again.")
        break
    else:
        # Otherwise switch the two Players for next round
        currentPlayer, nextPlayer = nextPlayer, currentPlayer

print("Thank you")
