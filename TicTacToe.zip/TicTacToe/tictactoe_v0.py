# Tic-Tac-Toe
print("Tic-Tac-Toe")

# Create the board
positions = ["TL", "TC", "TR",
             "ML", "MC", "MR",
             "BL", "BC", "BR"]
board = {}
for position in positions:
    board[position] = " "

# Set player symbols
currentPlayer, nextPlayer = "X", "O"

# Print the board
print()
print(" ", board["TL"], "|", board["TC"], "|", board["TR"], " ")
print("----+---+----")
print(" ", board["ML"], "|", board["MC"], "|", board["MR"])
print("----+---+----")
print(" ", board["BL"], "|", board["BC"], "|", board["BR"], " ")
print()
