# =========================================================================== #
# Tic-Tac-Toe game for two human players, created by Sourav Sen Gupta.
# Inspiration : "Automate the Boring Stuff with Python" by Al Sweigart
# =========================================================================== #
# This implementation of the Tic-Tac-Toe game
# 1. Sets up the board for two human players
# 2. Allows players to make alternate moves
# 3. Checks for ending conditions of the game
# 4. Determines and publishes the game outcome
# =========================================================================== #

# Functions for the Board

def createBoard():
    ''' Creates a blank Board for Tic-Tac-Toe
    '''
    positions = ["TL", "TC", "TR",
                 "ML", "MC", "MR",
                 "BL", "BC", "BR"]
    board = {}
    for position in positions:
        board[position] = " "
    return board

def printBoard(board):
    ''' Prints the Board for Tic-Tac-Toe
    '''
    print()
    print(" ", board["TL"], "|", board["TC"], "|", board["TR"], " ")
    print("----+---+----")
    print(" ", board["ML"], "|", board["MC"], "|", board["MR"])
    print("----+---+----")
    print(" ", board["BL"], "|", board["BC"], "|", board["BR"], " ")
    print()
    print("======================================================")
    print()

def updateBoard(board, position, symbol):
    ''' Updates the Board for Tic-Tac-Toe
    '''
    board[position] = symbol

# =========================================================================== #

# Functions for the Players

def getMove(board, player):
    ''' Gets input Move from the Player
    '''
    print("Enter move for", player)
    available = [position for position, value in board.items() if value == " "]
    print("Options:", available)
    move = input()
    return move

def validMove(board, move):
    ''' Checks if the Move is valid for the Board
    '''
    if move in board.keys():
        valid = (board[move] == " ")
    else:
        valid = False
    return valid

# =========================================================================== #

# Functions for Game Logic

def isWinner(board, player):
    ''' Checks if Player has Won the game
    '''
    # Check for 3 valid marks denoting a Win
    win = ((board['TL'] == board['TC'] == board['TR'] == player) or # Top Row
           (board['ML'] == board['MC'] == board['MR'] == player) or # Middle Row
           (board['BL'] == board['BC'] == board['BR'] == player) or # Bottom Row
           (board['TL'] == board['ML'] == board['BL'] == player) or # Left Column
           (board['TC'] == board['MC'] == board['BC'] == player) or # Center Column
           (board['TR'] == board['MR'] == board['BR'] == player) or # Right Column
           (board['TL'] == board['MC'] == board['BR'] == player) or # Diagonal
           (board['TR'] == board['MC'] == board['BL'] == player))   # Diagonal       
    
    return win

def isBoardFull(board):
    ''' Checks if the Board is Full
    '''
    available = any(position == " " for position in board.values())
    return (not available)

# =========================================================================== #

# Miscellaneous functions

def printIntro():
    ''' Prints the Introduction for Tic-Tac-Toe
    '''
    print()
    print("======================================================")
    print()
    print("This is the game of Tic-Tac-Toe for two human players.")
    print("First player gets symbol 'X' as default to start with.")
    print()
    print("The game is played on a 3x3 board, labeled as follows.")
    print()
    print("TL | TC | TR")
    print("---+----+---")
    print("ML | MC | MR")
    print("---+----+---")
    print("BL | BC | BR")
    print()
    print("======================================================")
    print()

def printFinal():
    ''' Prints the Conclusion for Tic-Tac-Toe
    '''
    print()
    print("Thank you for playing the game of Tic-Tac-Toe with us.")
    print("Feel free to review the game and suggest improvements.")
    print()
    print("======================================================")
    print()

# =========================================================================== #

# Function for the actual Game

def tictactoe():
    ''' Gameplay function for Tic-Tac-Toe
    '''
    # Introduction
    printIntro()

    # Initiate the game
    gameBoard = createBoard()
    currentPlayer, nextPlayer = "X", "O"
    printBoard(gameBoard)

    # Main gameplay loop
    while True:
        # Get the move of current Player and update Board
        while True:
            currentMove = getMove(gameBoard, currentPlayer)
            if validMove(gameBoard, currentMove):
                updateBoard(gameBoard, currentMove, currentPlayer)
                break
            else:
                print("Sorry, wrong move. Check again.")

        # Print the updated Board
        printBoard(gameBoard)
            
        # Check for terminate-or-continue conditions
        if isWinner(gameBoard, currentPlayer):
            # If the current Player Won the game
            print("Congratulations!", currentPlayer, "has won the game.")
            break
        elif isBoardFull(gameBoard):
            # If the Board is full and it's a Tie
            print("Wow! This game is a tie. Play again.")
            break
        else:
            # Otherwise switch the two Players for next round
            currentPlayer, nextPlayer = nextPlayer, currentPlayer

    # Conclusion
    printFinal()

# =========================================================================== #

# Main Function

if __name__ == "__main__":
    ''' Run the game when this module is run
    '''
    tictactoe()

# =========================================================================== #
