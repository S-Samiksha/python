# Tic-Tac-Toe
print("Tic-Tac-Toe")

# Create the board
positions = ["TL", "TC", "TR",
             "ML", "MC", "MR",
             "BL", "BC", "BR"]
board = {}
for position in positions:
    board[position] = " "

# Set player symbols
currentPlayer, nextPlayer = "X", "O"

# Print the board
print()
print(" ", board["TL"], "|", board["TC"], "|", board["TR"], " ")
print("----+---+----")
print(" ", board["ML"], "|", board["MC"], "|", board["MR"])
print("----+---+----")
print(" ", board["BL"], "|", board["BC"], "|", board["BR"], " ")
print()

# Main gameplay loop
while True:
    # Get the move of current Player and update Board
    print("Enter move for", currentPlayer)
    position = input()
    board[position] = currentPlayer
    
    # Print the updated Board
    print()
    print(" ", board["TL"], "|", board["TC"], "|", board["TR"], " ")
    print("----+---+----")
    print(" ", board["ML"], "|", board["MC"], "|", board["MR"])
    print("----+---+----")
    print(" ", board["BL"], "|", board["BC"], "|", board["BR"], " ")
    print()
        
    # Switch the two Players for next round
    currentPlayer, nextPlayer = nextPlayer, currentPlayer

print("Thank you")
